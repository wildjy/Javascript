// VERSION: 3.1 LAST UPDATE: 13.03.2012
/* 
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 * 
 * Made by Wilq32, wilq32@gmail.com, Wroclaw, Poland, 01.2009
 * Website: http://code.google.com/p/jqueryrotate/ 
 */

// Documentation removed from script file (was kinda useless and outdated)

(function($) {
var supportedCSS,styles=document.getElementsByTagName("head")[0].style,toCheck="transformProperty WebkitTransform OTransform msTransform MozTransform".split(" "); //MozTransform <- firefox works slower with css!!!
for (var a=0;a<toCheck.length;a++) if (styles[toCheck[a]] !== undefined) supportedCSS = toCheck[a];
// Bad eval to preven google closure to remove it from code o_O
// After compresion replace it back to var IE = 'v' == '\v'
var IE = eval('"v"=="\v"');

jQuery.fn.extend({
    rotate:function(parameters)
    {
        if (this.length===0||typeof parameters=="undefined") return;
            if (typeof parameters=="number") parameters={angle:parameters};
        var returned=[];
        for (var i=0,i0=this.length;i<i0;i++)
            {
                var element=this.get(i);        
                if (!element.Wilq32 || !element.Wilq32.PhotoEffect) {

                    var paramClone = $.extend(true, {}, parameters); 
                    var newRotObject = new Wilq32.PhotoEffect(element,paramClone)._rootObj;

                    returned.push($(newRotObject));
                }
                else { 
                    element.Wilq32.PhotoEffect._handleRotation(parameters);
                }
            }
            return returned;
    },
    getRotateAngle: function(){
        var ret = [];
        for (var i=0,i0=this.length;i<i0;i++)
            {
                var element=this.get(i);        
                if (element.Wilq32 && element.Wilq32.PhotoEffect) {
                    ret[i] = element.Wilq32.PhotoEffect._angle;
                }
            }
            return ret;
    },
    stopRotate: function(){
        for (var i=0,i0=this.length;i<i0;i++)
            {
                var element=this.get(i);        
                if (element.Wilq32 && element.Wilq32.PhotoEffect) {
                    clearTimeout(element.Wilq32.PhotoEffect._timer);
                }
            }
    }
});

// Library agnostic interface

Wilq32=window.Wilq32||{};
Wilq32.PhotoEffect=(function(){

        if (supportedCSS) {
                return function(img,parameters){
                        img.Wilq32 = {PhotoEffect: this};
            
            this._img = this._rootObj = this._eventObj = img;
            this._handleRotation(parameters);
                }
        } else if (IE) {
                return function(img,parameters) {
                        // Make sure that class and id are also copied - just in case you would like to refeer to an newly created object
            this._img = img;

                        this._rootObj=document.createElement('span');
                        this._rootObj.style.display="inline-block";
                        this._rootObj.Wilq32 = {PhotoEffect: this};
                        img.parentNode.insertBefore(this._rootObj,img);
            this._Loader(parameters);
                }
        } else {
        return function(img,parameters){
            // Just for now... Dont do anything if CSS3 is not supported
        this._rootObj = img;
        }
    }
})();

Wilq32.PhotoEffect.prototype={
    _setupParameters : function (parameters){
                this._parameters = this._parameters || {};
        if (typeof this._angle !== "number") this._angle = 0 ;
        if (typeof parameters.angle==="number") this._angle = parameters.angle;
        this._parameters.animateTo = (typeof parameters.animateTo==="number") ? (parameters.animateTo) : (this._angle); 

        this._parameters.step = parameters.step || this._parameters.step || null;
                this._parameters.easing = parameters.easing || this._parameters.easing || function (x, t, b, c, d) { return -c * ((t=t/d-1)*t*t*t - 1) + b; }
                this._parameters.duration = parameters.duration || this._parameters.duration || 1000;
        this._parameters.callback = parameters.callback || this._parameters.callback || function(){};
        if (parameters.bind && parameters.bind != this._parameters.bind) this._BindEvents(parameters.bind); 
        },
        _handleRotation : function(parameters){
          this._setupParameters(parameters);
          if (this._angle==this._parameters.animateTo) {
              this._rotate(this._angle);
          }
          else { 
              this._animateStart();          
          }
        },

        _BindEvents:function(events){
                if (events && this._eventObj) 
                {
            // Unbinding previous Events
            if (this._parameters.bind){
                var oldEvents = this._parameters.bind;
                for (var a in oldEvents) if (oldEvents.hasOwnProperty(a)) 
                        // TODO: Remove jQuery dependency
                        jQuery(this._eventObj).unbind(a,oldEvents[a]);
            }

            this._parameters.bind = events;
                        for (var a in events) if (events.hasOwnProperty(a)) 
                                // TODO: Remove jQuery dependency
                                        jQuery(this._eventObj).bind(a,events[a]);
                }
        },

        _Loader: function(parameters)
                {
                        var width=this._img.width;
                        var height=this._img.height;
                        //this._img.parentNode.removeChild(this._img);
            //this._rootObj.parentNode.removeChild(this._rootObj);
            
            this._rootObj.appendChild(this._img);

            this._rootObj.style.width = this._img.offsetWidth;
            this._rootObj.style.height = this._img.offsetHeight;

            this._img.style.position = "absolute";

            this._rootObj = this._img;
            this._rootObj.Wilq32 = {PhotoEffect: this}

            this._rootObj.style.filter += "progid:DXImageTransform.Microsoft.Matrix(M11=1,M12=1,M21=1,M22=1,sizingMethod='auto expand')";

                    this._eventObj = this._rootObj;     
                    this._handleRotation(parameters);
                },

        _animateStart:function()
        {       
                if (this._timer) {
                        clearTimeout(this._timer);
                }
                this._animateStartTime = +new Date;
                this._animateStartAngle = this._angle;
                this._animate();
        },
    _animate:function()
    {
         var actualTime = +new Date;
         var checkEnd = actualTime - this._animateStartTime > this._parameters.duration;

         // TODO: Bug for animatedGif for static rotation ? (to test)
         if (checkEnd && !this._parameters.animatedGif) 
         {
             clearTimeout(this._timer);
         }
         else 
         {
             if (this._canvas||this._vimage||this._img) {
                 var angle = this._parameters.easing(0, actualTime - this._animateStartTime, this._animateStartAngle, this._parameters.animateTo - this._animateStartAngle, this._parameters.duration);
                 this._rotate((~~(angle*10))/10);
             }
             if (this._parameters.step) {
                this._parameters.step(this._angle);
             }
             var self = this;
             this._timer = setTimeout(function()
                     {
                     self._animate.call(self);
                     }, 10);
         }

         // To fix Bug that prevents using recursive function in callback I moved this function to back
         if (this._parameters.callback && checkEnd){
             this._angle = this._parameters.animateTo;
             this._rotate(this._angle);
             this._parameters.callback.call(this._rootObj);
         }
     },

        _rotate : (function()
        {
                var rad = Math.PI/180;
                if (IE)
                return function(angle)
                {
            this._angle = angle;
                        //this._container.style.rotation=(angle%360)+"deg";
            var _rad = angle * rad ;
            costheta = Math.cos(_rad);
            sintheta = Math.sin(_rad);
            var fil = this._rootObj.filters.item("DXImageTransform.Microsoft.Matrix");
            fil.M11=costheta; fil.M12=-sintheta; fil.M21=sintheta; fil.M22=costheta;

            this._rootObj.style.marginLeft = -(this._rootObj.offsetWidth - this._rootObj.clientWidth)/2 +"px";
            this._rootObj.style.marginTop = -(this._rootObj.offsetHeight - this._rootObj.clientHeight)/2 +"px";
                }
                else if (supportedCSS)
                return function(angle){
            this._angle = angle;
                        this._img.style[supportedCSS]="rotate("+(angle%360)+"deg)";
                }

        })()
}
})(jQuery);